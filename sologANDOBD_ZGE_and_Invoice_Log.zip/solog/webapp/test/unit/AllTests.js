sap.ui.define([
	"matixcomlogsolog/solog/test/unit/controller/View.controller"
], function () {
	"use strict";
});
