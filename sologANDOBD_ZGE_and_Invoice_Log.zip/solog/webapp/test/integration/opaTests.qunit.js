/* global QUnit */

sap.ui.require(["matix/com/log/solog/solog/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
