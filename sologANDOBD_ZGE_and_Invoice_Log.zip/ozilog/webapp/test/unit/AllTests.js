sap.ui.define([
	"matixcomlogozilog/ozilog/test/unit/controller/View.controller"
], function () {
	"use strict";
});
