/* global QUnit */

sap.ui.require(["matix/com/log/ozilog/ozilog/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
