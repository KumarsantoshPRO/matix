sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("matix.com.log.ozilog.ozilog.controller.View", {
      onInit() {
      }
  });
});