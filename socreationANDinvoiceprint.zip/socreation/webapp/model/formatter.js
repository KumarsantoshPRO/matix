sap.ui.define(["sap/ui/base/ManagedObject"], function (ManagedObject) {
  "use strict";

  return ManagedObject.extend(
    "matix.com.sp.socreation.socreation.model.formatter",
    {
      quntity: function (sValue) {
        debugger;
      },
    }
  );
});
