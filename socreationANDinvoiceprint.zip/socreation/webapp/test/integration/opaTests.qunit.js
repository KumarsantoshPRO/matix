/* global QUnit */

sap.ui.require(["matix/com/sp/socreation/socreation/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
