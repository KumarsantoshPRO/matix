sap.ui.define([
	"matixcomspsocreation/socreation/test/unit/controller/View.controller"
], function () {
	"use strict";
});
