sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("matix.com.sp.socreation.socreation.controller.App", {
      onInit() {
      }
  });
});