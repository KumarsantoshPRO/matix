/* global QUnit */

sap.ui.require(["matix/com/rep/invoiceprint/zinvoiceprint/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
